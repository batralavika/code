package com.hackerrank.tradingplatform.dto;

public class TraderDTO {
    private final String name;
    private final String email;
    private final Double balance;

    public TraderDTO(String name, String email, Double balance) {
        this.name = name;
        this.email = email;
        this.balance = balance;
    }

    

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public Double getBalance() {
        return balance;
    }
}
