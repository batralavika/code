package com.hackerrank.tradingplatform.controller;

import java.util.List;

import org.apache.catalina.connector.Response;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hackerrank.tradingplatform.dto.TraderDTO;
import com.hackerrank.tradingplatform.service.TraderService;

@RestController
@RequestMapping("/trading/traders")
public class TraderController {

    TraderService traderService;

    public TraderController(TraderService traderService) {
        this.traderService = traderService;
    }

    @PostMapping("/register")
    public ResponseEntity<?> createUser(@RequestBody TraderDTO traderDTO) {
        TraderDTO traderDto = traderService.createDto(traderDTO);
        if (traderDto == null)
            return new ResponseEntity<>(HttpStatus.valueOf(400));
        return new ResponseEntity<>(traderDto, HttpStatus.CREATED);
    }

    @GetMapping("/all")
    public ResponseEntity<List<TraderDTO>> getAllTraders(){
        return new ResponseEntity<>(traderService.getAll(),HttpStatus.OK);
    }

    @GetMapping("/{email}")
    public ResponseEntity<?> findByEmail(@PathVariable String email) {
        TraderDTO traderDTO = traderService.getByEmail(email);
        if (traderDTO == null)
            return new ResponseEntity<>(HttpStatus.valueOf(404));
        return new ResponseEntity<>(traderDTO, HttpStatus.OK);
    }

    @PutMapping()
    public ResponseEntity<> updatedTrade(@RequestBody TraderDTO traderDTO , @PathVariable String email){
        
    }


}
