package com.hackerrank.tradingplatform.service;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hackerrank.tradingplatform.dto.TraderDTO;
import com.hackerrank.tradingplatform.model.Trader;
import com.hackerrank.tradingplatform.repository.TraderRepository;

@Service
public class TraderService {

    TraderRepository traderRepository;

    public TraderService(TraderRepository traderRepository) {
        this.traderRepository = traderRepository;
    }

    public TraderDTO createDto(TraderDTO tradeDto) {
        if (traderRepository.findByEmail(tradeDto.getEmail()).isPresent())
            return null;
        Trader trader = new Trader(tradeDto.getName(), tradeDto.getEmail(), tradeDto.getBalance());
        Trader trade = traderRepository.save(trader);
        TraderDTO obj = new TraderDTO(trade.getName(), trade.getEmail(), trade.getBalance());
        return obj;
    }

    public List<TraderDTO> getAll() {
        // List<Trader> traderList = traderRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
        // List<TraderDTO> traderDtoList = new ArrayList<>();
        // for (Trader trader: traderList) {
        //     TraderDTO traderDTO = new TraderDTO(trader.getName(), trader.getEmail(), trader.getBalance());
        //     traderDtoList.add(traderDTO);
        // }
        // return traderDtoList;
        return traderRepository.findAll(Sort.by(Sort.Direction.ASC, "id")).stream().map(i -> new TraderDTO(i.getName(), i.getEmail(), i.getBalance())).collect(Collectors.toList());
    }

    public TraderDTO getByEmail(String email) {
        Trader trader = traderRepository.findByEmail(email).orElse(null);
        // object is present or null 
        if (trader == null)
            return null;
        TraderDTO traderDto = new TraderDTO(trader.getName(), trader.getEmail(), trader.getBalance());
        return traderDto;
    }


    public List<TraderDTO> gettalL(){
        return traderRepository.findAll(Sort.by(Sort.Direction.ASC,"id")).stream().map(i-> new TraderDTO (i.getName(), i.getEmail(),i.getBalance())).collect(Collectors.toList());
        
    }

    public TraderDTO updateEmail(String email){
        TraderDTO traderDTO = traderRepository.findByEmail(email).orElse(null);
        if(traderDTO == null) return null;
        if(traderDTO.getName()!=null) traderDTO.
        if(traderDTO!=null)
    }

}
