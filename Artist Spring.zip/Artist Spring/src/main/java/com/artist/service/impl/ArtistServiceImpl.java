package com.artist.service.impl;

import com.artist.dto.ArtistRequest;
import com.artist.model.Artist;
import com.artist.repository.ArtistRepository;
import com.artist.service.ArtistService;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ArtistServiceImpl implements ArtistService {
    private final ArtistRepository artistRepository;

    public ArtistServiceImpl(ArtistRepository artistRepository) {
        this.artistRepository = artistRepository;
    }

    @Override
    public Artist createArtist(ArtistRequest artistRequest) {
    Artist artist = new Artist(artistRequest.firstName(),artistRequest.lastName());
    Artist artistR= artistRepository.save(artist);
    return artistR;
    }

    @Override
    public List<Artist> getArtists() {
        return artistRepository.findAll(Sort.by(Sort.Direction.ASC,"id"));
    }

    @Override
    public Artist getArtistByID(Long id) {
        Artist artist =artistRepository.findById(id).get();
        if  (artist== null) return null; 
       return artist;
    }

    @Override
    public void deleteArtist(Long id) {
     artistRepository.deleteById(id);     
    }
}
