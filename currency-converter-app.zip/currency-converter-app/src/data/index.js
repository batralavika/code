const exchangeRate = [
    {
        currency: "INR",
        rate: 0.011
    },
    {
        currency: "PND",
        rate: 1.34
    },
    {
        currency: "EURO",
        rate: 1.17
    },
    {
        currency: "DINAR",
        rate: 0.00076
    },
    {
        currency: "YEN",
        rate: 0.0067
    },
];

const defaultCurrency = "INR";
const defaultValue = 0.011;

export {exchangeRate, defaultCurrency, defaultValue };