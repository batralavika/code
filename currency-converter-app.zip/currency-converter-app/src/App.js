import './App.css';
import { exchangeRate, defaultCurrency, defaultValue } from "./data";

function App() {

  // 1. Default value should be 1
  // 2. The value of currency in dollar should be calcualted when eitheir input value is changed or some other currency is selected from the option.
  // 3. Clicking on Reset button should reset the value to default value of INR and input value as 1
  // 4. The result value should be shown to 3 decimal places only

  return (
    <div className='flex flex-col items-center'>
      <h1 className='text-4xl text-center text-gray-800 my-10'>
        Currency Converter
      </h1>
      <div className='flex justify-evenly gap-5 bg-yellow-50 px-10 py-20 mx-20 rounded-lg'>
        <section className='flex flex-col justify-evenly gap-10 max-w-1/2'>
          <select className='rounded-sm p-2 text-xl cursor-pointer border-b-2 border-blue-200'>
            <option>PND</option>
          </select>
          <input
            className='py-2 px-4 text-xl outline-none rounded-md w-fit bg-slate-200 mt-2'
            placeholder={"Enter value in INR"}
            value={"1"}
            type="number" />
        </section>
        <div className='h-48 w-[2px] bg-red-400' />
        <section className='flex flex-col justify-evenly gap-10 max-w-1/2'>
          <p className='rounded-sm p-1 text-xl border-b-2 border-blue-200 mt-1'>
            Dollar
          </p>
          <input
            className='py-2 px-4 text-xl bg-slate-200 outline-none rounded-md'
            value={"1"}
            type="text" />
        </section>
      </div>
      <button className='border-none py-2 px-4 text-white bg-green-500 rounded-sm my-4 hover:bg-green-600'>Reset</button>
    </div>
  );
}

export default App;
